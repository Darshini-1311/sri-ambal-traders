const $ = s => document.querySelector(s);
document.querySelectorAll('.explore-trigger').forEach(b => b.addEventListener('click', () => $('#collection').scrollIntoView({behavior:'smooth'})));
const products = {
 sweet:{no:'01 / SWEET PACKAGING',title:'Plastic Sweet Boxes',text:'A bright, protective presentation for sweets and savouries. Choose the print method that suits your product and identity.',tags:['IML Printing','Screen Printing','Food packaging']},
 board:{no:'02 / PAPERBOARD',title:'ITC Board Boxes',text:'Well-finished board boxes designed for gifting, sweets and cakes—bringing structure and a premium finish to every handover.',tags:['Sweet Boxes','Cake Boxes','ITC Board']},
 containers:{no:'03 / CONTAINERS',title:'Plastic Containers',text:'A versatile range for snacks, curries and complete meals, including generous biryani box capacities.',tags:['50ml','90ml','100ml','120ml','250ml','300ml','500ml Biryani','750ml Biryani']},
 corrugated:{no:'04 / SHIPPING',title:'Corrugated Boxes',text:'Dependable corrugated packaging designed to keep contents supported and protected in transit or storage.',tags:['Protective','Practical','Reliable']},
 cake:{no:'05 / CAKE BASES',title:'MDF Cake Bases',text:'A sturdy, celebration-ready base available in gold or white, round or square, from ½ kg to 5 kg.',tags:['Gold / White','Round / Square','8–20 inch','½–5 kg']}
};
const modal=$('#modal');
document.querySelectorAll('.product-card').forEach(card=>card.addEventListener('click',()=>{const p=products[card.dataset.product];$('#modalNo').textContent=p.no;$('#modalTitle').textContent=p.title;$('#modalText').textContent=p.text;$('#modalTags').innerHTML=p.tags.map(t=>`<span>${t}</span>`).join('');modal.classList.add('open');modal.setAttribute('aria-hidden','false')}));
$('#closeModal').addEventListener('click',()=>modal.classList.remove('open'));modal.addEventListener('click',e=>{if(e.target===modal)modal.classList.remove('open')});
const base=$('#studioBase'),sizes=[['½ kg','8 inch'],['1 kg','10 inch'],['1.5 kg','11 inch'],['2 kg','12 inch'],['3 kg','14 inch'],['4 kg','16 inch'],['5 kg','20 inch']];
function select(group,attr){document.querySelectorAll(group+' .choice').forEach(b=>b.classList.toggle('active',b.dataset[attr]===base.dataset[attr]));}
$('#colorChoices').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;base.classList.toggle('white',b.dataset.color==='white');base.classList.toggle('gold',b.dataset.color==='gold');base.dataset.color=b.dataset.color;select('#colorChoices','color')});
$('#shapeChoices').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;base.classList.toggle('square',b.dataset.shape==='square');base.classList.toggle('round',b.dataset.shape==='round');base.dataset.shape=b.dataset.shape;select('#shapeChoices','shape')});
$('#sizeRange').addEventListener('input',e=>{const n=+e.target.value;base.classList.remove(...Array.from({length:7},(_,i)=>'size-'+i));base.classList.add('size-'+n);$('#sizeLabel').textContent=sizes[n][0];$('#sizeReadout').textContent=sizes[n][1]+' · '+sizes[n][0]});
$('#baseStage').addEventListener('mousemove',e=>{const r=e.currentTarget.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;base.style.transform=`rotateX(${64-y*7}deg) rotateZ(${-12+x*9}deg)`});$('#baseStage').addEventListener('mouseleave',()=>base.style.transform='');
